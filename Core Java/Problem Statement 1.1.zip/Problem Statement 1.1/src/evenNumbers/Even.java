package evenNumbers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
		 System.out.println("Enter number : ");
		 int num = 0;
		try {
			num = Integer.parseInt(br1.readLine());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 System.out.println("Even Numbers:");
		 for (int i=1;i <=num ; i++) {
			 if(i%2==0 ) {
				 System.out.print(i + " ");
			 }
		 }
	}

}
